package com.m2i.RestWithBdd.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="message")
public class Message {
	
	@Id
	@GeneratedValue
	private int id;
	
	private String author;
	private Date date;
	private String text;
	
}
