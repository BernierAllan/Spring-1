package com.m2i.RestWithBdd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestWithBddApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestWithBddApplication.class, args);
	}

}
