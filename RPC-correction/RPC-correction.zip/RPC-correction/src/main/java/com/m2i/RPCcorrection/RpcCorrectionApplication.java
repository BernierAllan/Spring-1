package com.m2i.RPCcorrection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RpcCorrectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(RpcCorrectionApplication.class, args);
	}

}
